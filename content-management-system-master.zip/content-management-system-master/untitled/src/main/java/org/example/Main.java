package org.example;

public class Main {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 5};
        boolean hasDuplicates = checkForConsecutiveDuplicates(array);
        System.out.println("Contains consecutive duplicates: " + hasDuplicates);
    }

    static boolean checkForConsecutiveDuplicates(int[] array) {
        for (int i = 0; i < array.length - 1; i++) { // Changed to 'array.length - 1' to avoid accessing out-of-bounds
            if (array[i] == array[i + 1]) {
                return true; // Returns true if a consecutive duplicate is found
            }
        }
        return false; // Returns false if no consecutive duplicates are found
    }
}