$(document).ready(function () {
    window.setTimeout(function () {
        location.href = "/home";
    }, 3000);
});